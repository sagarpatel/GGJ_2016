﻿using UnityEngine;
using System.Collections;

public class PlayerData : MonoBehaviour
{
    public int m_playerIndex;

}
